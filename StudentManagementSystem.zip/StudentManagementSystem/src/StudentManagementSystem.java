import java.sql.*;
import java.util.Scanner;

public class StudentManagementSystem {
    private static final String URL = "jdbc:mysql://localhost:3306/student_db";
    private static final String USER = "root";
    private static final String PASS = "";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;

        try (Connection conn = DriverManager.getConnection(URL, USER, PASS)) {
            do {
                System.out.println("\n===== Student Management System =====");
                System.out.println("1. Add Student");
                System.out.println("2. View All Students");
                System.out.println("3. Search Student by Roll No");
                System.out.println("4. Update Student by Roll No");
                System.out.println("5. Delete Student by Roll No");
                System.out.println("6. Analytics");
                System.out.println("7. Exit");
                System.out.print("Enter your choice: ");
                choice = sc.nextInt();
                sc.nextLine();

                switch (choice) {
                    case 1 -> addStudent(conn, sc);
                    case 2 -> viewStudents(conn);
                    case 3 -> searchStudent(conn, sc);
                    case 4 -> updateStudent(conn, sc);
                    case 5 -> deleteStudent(conn, sc);
                    case 6 -> showAnalytics(conn);
                    case 7 -> System.out.println("Exiting program...");
                    default -> System.out.println("Invalid choice! Please try again.");
                }
            } while (choice != 7);
        } catch (SQLException e) {
            System.out.println("[Error] Database connection failed: " + e.getMessage());
        }
        sc.close();
    }

    private static void addStudent(Connection conn, Scanner sc) {
        try {
            System.out.print("Enter Roll No: ");
            int rollNo = sc.nextInt();
            sc.nextLine();
            System.out.print("Enter Name: ");
            String name = sc.nextLine();
            System.out.print("Enter Age: ");
            int age = sc.nextInt();

            String query = "INSERT INTO students (rollNo, name, age) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, rollNo);
            stmt.setString(2, name);
            stmt.setInt(3, age);

            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("[Success] Student added successfully!");
        } catch (SQLException e) {
            System.out.println("[Error] Error adding student: " + e.getMessage());
        }
    }

    private static void viewStudents(Connection conn) {
        String query = "SELECT * FROM students ORDER BY rollNo";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            System.out.println("\n--- Student List ---");
            System.out.printf("%-10s %-20s %-5s%n", "RollNo", "Name", "Age");
            System.out.println("-------------------------------------");
            while (rs.next()) {
                System.out.printf("%-10d %-20s %-5d%n",
                        rs.getInt("rollNo"), rs.getString("name"), rs.getInt("age"));
            }
        } catch (SQLException e) {
            System.out.println("[Error] Error viewing students: " + e.getMessage());
        }
    }

    private static void searchStudent(Connection conn, Scanner sc) {
        System.out.print("Enter Roll No to search: ");
        int rollNo = sc.nextInt();
        String query = "SELECT * FROM students WHERE rollNo=?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, rollNo);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("[Success] Student Found: RollNo: " + rs.getInt("rollNo") +
                        ", Name: " + rs.getString("name") + ", Age: " + rs.getInt("age"));
            } else {
                System.out.println("[Error] Student not found.");
            }
        } catch (SQLException e) {
            System.out.println("[Error] Error searching student: " + e.getMessage());
        }
    }

    private static void updateStudent(Connection conn, Scanner sc) {
        System.out.print("Enter Roll No to update: ");
        int rollNo = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter new Name: ");
        String name = sc.nextLine();
        System.out.print("Enter new Age: ");
        int age = sc.nextInt();

        String query = "UPDATE students SET name=?, age=? WHERE rollNo=?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setInt(2, age);
            stmt.setInt(3, rollNo);
            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("[Success] Student updated successfully!");
            else System.out.println("[Error] Student not found.");
        } catch (SQLException e) {
            System.out.println("[Error] Error updating student: " + e.getMessage());
        }
    }

    private static void deleteStudent(Connection conn, Scanner sc) {
        System.out.print("Enter Roll No to delete: ");
        int rollNo = sc.nextInt();
        String query = "DELETE FROM students WHERE rollNo=?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, rollNo);
            int rows = stmt.executeUpdate();
            if (rows > 0) System.out.println("[Success] Student deleted successfully!");
            else System.out.println("[Error] Student not found.");
        } catch (SQLException e) {
            System.out.println("[Error] Error deleting student: " + e.getMessage());
        }
    }

    private static void showAnalytics(Connection conn) {
        String query = "SELECT COUNT(*) AS total, AVG(age) AS avg_age, MIN(age) AS min_age, MAX(age) AS max_age FROM students";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            if (rs.next()) {
                System.out.println("\n--- Analytics ---");
                System.out.println("Total Students: " + rs.getInt("total"));
                System.out.println("Average Age: " + rs.getDouble("avg_age"));
                System.out.println("Youngest Student Age: " + rs.getInt("min_age"));
                System.out.println("Oldest Student Age: " + rs.getInt("max_age"));
            }
        } catch (SQLException e) {
            System.out.println("[Error] Error showing analytics: " + e.getMessage());
        }
    }
}
